# AppLab v0.8 local SBEF findings

Changes: optional approved source-project npm build, build logs, dependency installation with lifecycle scripts disabled, case-collision ZIP rejection, transactional AI edit rollback on write errors, improved encoded URL validation. No GitHub push/deploy.

Important: npm run build executes untrusted project scripts after explicit confirmation; do not run unknown ZIPs. This is not a secure execution sandbox. Browser regression, Ollama installer and media pipelines, Windows/macOS installer validation remain unverified. This is a development source archive, not a finished desktop release.
