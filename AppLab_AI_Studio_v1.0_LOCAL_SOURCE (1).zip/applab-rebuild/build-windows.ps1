$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
node --version
npm --version
npm install
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed' }
npm test
if ($LASTEXITCODE -ne 0) { throw 'Tests failed' }
npm run dist:win
if ($LASTEXITCODE -ne 0) { throw 'Windows installer build failed' }
Write-Host 'Check the release folder for the installer. Install and test it before sharing.'
