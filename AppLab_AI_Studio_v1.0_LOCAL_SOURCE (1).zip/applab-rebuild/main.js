'use strict';
const {app,BrowserWindow,dialog,ipcMain,shell}=require('electron');const path=require('node:path'),fs=require('node:fs');const {inspectZip}=require('./inspector'),ai=require('./ai-core'),installer=require('./installer'),engine=require('./project-engine'),agent=require('./agent'),internet=require('./internet'),builder=require('./build-engine'),sbef=require('./sbef'),preview=require('./preview-server');
let window,project=null,pending=null,lastApplied=null,verifiedInstaller=null,previewSession=null;const active=new Map();
function create(){window=new BrowserWindow({width:1380,height:900,minWidth:940,minHeight:650,webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true}});window.loadFile('index.html');window.webContents.session.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));window.webContents.setWindowOpenHandler(()=>({action:'deny'}));window.webContents.on('will-navigate',(event,url)=>{if(!url.startsWith('file://'))event.preventDefault()})}
function send(channel,data){if(window&&!window.isDestroyed())window.webContents.send(channel,data)}
function operation(id,work){if(active.has(id))throw Error('Operation already active');const c=new AbortController();active.set(id,c);return Promise.resolve().then(()=>work(c.signal)).finally(()=>active.delete(id))}
function requireProject(){if(!project)throw Error('Import a project ZIP first');return project.root}
app.whenReady().then(()=>{
 const guarded=(channel,fn)=>ipcMain.handle(channel,(event,...args)=>{if(!window||event.sender!==window.webContents||!event.senderFrame||event.senderFrame!==window.webContents.mainFrame)throw Error('Untrusted IPC sender');return fn(event,...args)});

 guarded('inspect',async()=>{const r=await dialog.showOpenDialog(window,{properties:['openFile'],filters:[{name:'ZIP',extensions:['zip']}]});if(r.canceled)return null;try{return inspectZip(r.filePaths[0])}catch(e){return {status:'FAIL',errors:[e.message],warnings:[],files:[]}}});
 guarded('save-report',async(_e,report)=>{if(JSON.stringify(report).length>2_000_000)throw Error('Report too large');const r=await dialog.showSaveDialog(window,{defaultPath:'applab-report.json',filters:[{name:'JSON',extensions:['json']}]});if(r.canceled)return false;fs.writeFileSync(r.filePath,JSON.stringify(report,null,2));return true});
 guarded('internet-status',()=>internet.internetStatus());
 guarded('internet-docs',(_e,url)=>internet.docsRead(url));
 guarded('ai-system',()=>ai.systemInfo());guarded('ai-health',()=>ai.health());guarded('ai-models',()=>ai.MODELS);
 guarded('ai-pull',(_e,name)=>operation('pull',signal=>ai.pull(name,x=>send('ai-pull-progress',x),signal)));
 guarded('ai-delete',(_e,name)=>ai.deleteModel(name));
 guarded('ai-chat',(_e,data)=>operation('chat',signal=>ai.chat(data,x=>send('ai-chat-token',x),signal)));
 guarded('ai-cancel',(_e,id)=>{const c=active.get(id);if(c)c.abort();return !!c});
 guarded('ai-file',async()=>{const r=await dialog.showOpenDialog(window,{properties:['openFile'],filters:[{name:'Documents, code and media',extensions:['txt','md','pdf','docx','xlsx','pptx','csv','json','js','jsx','ts','tsx','html','css','py','java','go','rs','c','cpp','h','cs','php','sql','xml','yaml','yml','toml','log','sh','ps1','svg','zip','png','jpg','jpeg','webp','gif','wav','mp3','m4a','flac','ogg','mp4','mov','mkv','webm']}]});if(r.canceled)return null;return ai.readAttachment(r.filePaths[0])});
 guarded('installer-info',()=>installer.installationInfo());
 guarded('installer-download',()=>operation('install',async signal=>{verifiedInstaller=await installer.downloadOfficial({signal,onProgress:x=>send('installer-progress',x)});return {platform:verifiedInstaller.platform}}));
 guarded('installer-launch',()=>{if(!verifiedInstaller)throw Error('Download the official installer first');const result=installer.launchInstaller(verifiedInstaller);verifiedInstaller=null;return result});
 guarded('preview-stop',async()=>{if(previewSession){await new Promise(resolve=>previewSession.server.close(resolve));previewSession=null}return true});
 guarded('preview-start',async()=>{const root=requireProject(),pub=engine.choosePublish(root);if(!pub)throw Error('Build the static project before preview');if(previewSession){await new Promise(resolve=>previewSession.server.close(resolve));previewSession=null}previewSession=await preview.start(pub);const test=await preview.smoke(previewSession.url);if(!test.ok)throw Error('Preview smoke test failed');return {url:previewSession.url,smoke:test}});
 guarded('preview-open',async()=>{if(!previewSession)throw Error('Start preview first');await shell.openExternal(previewSession.url);return true});
 guarded('project-import',async()=>{const r=await dialog.showOpenDialog(window,{properties:['openFile'],filters:[{name:'Project ZIP',extensions:['zip']}]});if(r.canceled)return null;const next=engine.importZip(r.filePaths[0]);if(previewSession){await new Promise(resolve=>previewSession.server.close(resolve));previewSession=null}if(project)fs.rmSync(project.workspace,{recursive:true,force:true});project=next;pending=null;lastApplied=null;return {source:project.source,files:engine.listFiles(project.root).length,context:engine.projectContext(project.root).files.slice(0,50)}});
 guarded('project-context',()=>engine.projectContext(requireProject()));
 guarded('project-sbef',()=>sbef.scan(requireProject()));
 guarded('chat-export',async(_e,history)=>{if(!Array.isArray(history)||history.length>200||JSON.stringify(history).length>1000000)throw Error('Invalid chat history');const r=await dialog.showSaveDialog(window,{defaultPath:'applab-chat.json',filters:[{name:'JSON',extensions:['json']}]});if(r.canceled)return null;fs.writeFileSync(r.filePath,JSON.stringify({format:'applab-chat-v1',messages:history},null,2),{flag:'w'});return true});
 guarded('project-propose',(_e,{model,instruction})=>operation('propose',signal=>agent.propose(requireProject(),model,instruction,ai.chat,signal).then(x=>(pending=x,{summary:x.summary,edits:x.edits.map(e=>({path:e.path,action:e.action,reason:e.reason,beforeLength:e.before?.length||0,afterLength:e.content.length,preview:e.content.slice(0,5000)}))}))));
 guarded('project-apply',()=>{if(!pending)throw Error('No reviewed proposal');const root=requireProject();lastApplied=engine.apply(root,pending);pending=null;return {files:lastApplied.edits.map(x=>x.path),validation:engine.validate(engine.choosePublish(root)||root)}});
 guarded('project-rollback',()=>{if(!lastApplied)throw Error('No changes to roll back');engine.rollback(requireProject(),lastApplied);lastApplied=null;return true});
 guarded('project-autofix',()=>{const root=requireProject();pending=null;return engine.safeFix(engine.choosePublish(root)||root)});
 guarded('project-build-plan',()=>builder.buildPlan(requireProject()));
 guarded('project-build',()=>operation('build',signal=>builder.build(requireProject(),{signal,onLog:x=>send('project-build-log',x)})));
 guarded('project-validate',()=>{const root=requireProject();const publish=engine.choosePublish(root);return {publish:publish?path.relative(root,publish)||'.':null,errors:publish?engine.validate(publish):['No static index.html found; build source before exporting']}});
 guarded('project-export',async()=>{const root=requireProject();const r=await dialog.showSaveDialog(window,{defaultPath:'AppLab-NETLIFY-READY.zip',filters:[{name:'ZIP',extensions:['zip']}]});if(r.canceled)return null;return engine.exportNetlify(root,r.filePath)});
 create();
});
app.on('before-quit',()=>{if(previewSession){previewSession.server.close();previewSession=null}for(const c of active.values())c.abort();if(project)try{fs.rmSync(project.workspace,{recursive:true,force:true})}catch{}});app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)create()});
