# AppLab Studio 2.0 — rebuilt interface

New six-section desktop UI: AI Workspace, AI App Builder, Project Repair, Ollama Setup Center, Model Library, ZIP Inspector. The AI Builder is a guided workflow around the existing ZIP import, AI proposal/review, SBEF, static validation, preview and export. It does not generate a project from scratch or automatically execute arbitrary AI code.

## How to run

Install Node.js LTS and run `npm install`, then `npm start` inside the extracted folder. Use Ollama Setup Center to download the official installer, complete OS prompts, choose and download a model, then use AI Workspace. To build Windows installer: `npm run dist:win` on Windows. No compiled EXE is included.

## Honest validation limits

Node tests and JS syntax can be run locally; real Electron UI, OS installation, live Ollama inference, and Windows installer need testing on the target machine. Never claim these are proven without running them.
