'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const html=fs.readFileSync('index.html','utf8'),js=fs.readFileSync('renderer.js','utf8');
test('every button id is wired',()=>{const ids=[...html.matchAll(/<button\b[^>]*\bid="([^"]+)"/g)].map(m=>m[1]);assert.deepEqual(ids.filter(id=>!js.includes("$('"+id+"').onclick")&&!js.includes("$('"+id+"').addEventListener")&&!id.startsWith('nav-')),[])});
test('AI app generation invokes actual backend',()=>{assert.match(js,/window\.applab\.createProject\(/);assert.match(fs.readFileSync('preload.js','utf8'),/createProject:/)});
