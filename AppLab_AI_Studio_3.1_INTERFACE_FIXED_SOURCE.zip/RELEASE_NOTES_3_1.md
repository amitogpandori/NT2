# AppLab AI Studio 3.1 — Interface wiring repair

- Connected the previously inert prompt-to-app Generate button to the actual local Ollama IPC builder.
- Connected the builder import, AI proposal, SBEF, validation, preview, browser-open and export buttons.
- Connected the top-level health, setup, model navigation, model refresh and example-prompt controls.
- Added UI wiring regression tests; 27 tests pass on Node.js.
- Upgraded checkout GitHub Action to v5.

## Important limitations
- Windows installer is produced by GitHub Actions or `npm run dist:win`; this archive is source, not an EXE.
- Ollama must be installed and running, with a downloaded model. No live Windows/Ollama end-to-end run was performed in this environment.
- The generator produces static HTML/CSS/JS apps, not arbitrary native desktop apps.
- Building imported projects executes their build scripts; only build trusted sources.
