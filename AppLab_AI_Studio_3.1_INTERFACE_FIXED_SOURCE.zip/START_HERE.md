# AppLab AI Studio 3.0

This is the **AppLab** Electron application, not NETBOOST.

## Windows quick start
1. Install Node.js 22 LTS.
2. Open a terminal in this folder.
3. Run `npm install` then `npm start`.
4. Open **AI Setup** and install official Ollama with your approval.
5. Open **Model Manager**, download a compatible model, then use AI Workspace or AI App Builder.

## Windows installer
Run `npm run dist:win` on Windows. The NSIS `.exe` will appear in `release/`. This ZIP contains source, not a precompiled installer.

## GitHub
Upload the **contents of this folder to the root** of `amitogpandori/APPLAB`. The included GitHub Actions workflow runs unit tests and builds a Windows installer.

## Important limitations
The app builder creates static HTML/CSS/JS projects, not arbitrary native apps. AI-generated code needs review. Building imported projects may run third-party scripts, so approve only trusted code. Ollama must be installed and running for AI operations. No live Ollama or GUI test was performed during this source build.
