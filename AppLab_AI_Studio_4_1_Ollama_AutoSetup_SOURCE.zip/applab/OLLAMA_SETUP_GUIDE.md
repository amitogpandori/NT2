# AppLab Ollama automatic setup (Windows)
Open **Ollama Setup** and select **Automatic 7-step setup**.
1. Detect Ollama using local API and CLI.
2. Preserve existing installation; otherwise install via winget with silent mode. If unavailable, launch official installer and wait for completion.
3. Start/reconnect local Ollama server.
4. Detect RAM, CPU and GPU (Windows CIM).
5. Select recommended local coding model and download with progress; skip if already installed.
6. Test local inference.
7. Mark AI Chat ready.

The setup does not modify existing Ollama models, require cloud login, or guarantee unattended installation if Windows prompts are required. The model download needs internet and sufficient disk space. Cancel is supported.
