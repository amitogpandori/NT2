'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const html=fs.readFileSync('index.html','utf8'),js=fs.readFileSync('renderer.js','utf8'),preload=fs.readFileSync('preload.js','utf8');
test('all seven real Studio workspaces exist',()=>{for(const name of ['home','chat','builder','repair','system','models','project'])assert.match(html,new RegExp('id="'+name+'-view"'))});
test('all button ids are bound by renderer or handled through data-open',()=>{const ids=[...html.matchAll(/<button\\b[^>]*\\bid="([^"]+)"/g)].map(m=>m[1]);const missing=ids.filter(id=>!js.includes("$('"+id+"')")&&!id.startsWith('nav-'));assert.deepEqual(missing,[])});
test('auto setup uses IPC and progress',()=>{assert.match(js,/ollamaAutoSetup/);assert.match(js,/onOllamaSetupProgress/);assert.match(preload,/ollamaAutoSetup:/);assert.match(preload,/onOllamaSetupProgress:/)});
test('one existing renderer loaded and no missing studio.js',()=>{assert.ok(html.includes('<script src="renderer.js"></script>'));assert.doesNotMatch(html,/<script src="studio.js">/)});
test('CSP and no external scripts',()=>{assert.match(html,/Content-Security-Policy/);assert.ok(!html.includes('src="https://'))});
