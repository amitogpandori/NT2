'use strict';
const os=require('node:os'),path=require('node:path'),fs=require('node:fs');
const {spawn}=require('node:child_process');
const ai=require('./ai-core');
const installer=require('./installer');
const API='http://127.0.0.1:11434';
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function run(command,args,{timeout=180000,signal,onOutput=()=>{}}={}){
 return new Promise((resolve,reject)=>{
  const child=spawn(command,args,{windowsHide:true,env:process.env});
  let output='',done=false;
  const timer=setTimeout(()=>{child.kill();finish(Error('Command timed out'))},timeout);
  const abort=()=>{child.kill();finish(Error('Cancelled'))};
  const finish=(error,result)=>{if(done)return;done=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);error?reject(error):resolve(result)};
  signal?.addEventListener('abort',abort,{once:true});
  child.on('error',e=>finish(e));
  for(const stream of [child.stdout,child.stderr])stream?.on('data',data=>{const line=String(data);output=(output+line).slice(-5000);onOutput(line)});
  child.on('close',code=>code===0?finish(null,output):finish(Error(command+' exited '+code+': '+output.slice(-500))));
 });
}
function candidates(){
 if(process.platform!=='win32')return ['ollama'];
 return [path.join(process.env.LOCALAPPDATA||'','Programs','Ollama','ollama.exe'),path.join(process.env.ProgramFiles||'','Ollama','ollama.exe'),'ollama'];
}
async function installed(){
 const h=await ai.health();if(h.online)return {installed:true,running:true,path:null,models:h.models};
 for(const candidate of candidates()){try{await run(candidate,['--version'],{timeout:6000});return {installed:true,running:false,path:candidate,models:[]}}catch{}}
 return {installed:false,running:false,path:null,models:[]};
}
async function hardware(){
 const base=ai.systemInfo();let gpu=[];
 if(process.platform==='win32'){
  try{const output=await run('powershell.exe',['-NoProfile','-NonInteractive','-Command','Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name'],{timeout:12000});gpu=output.split(/\r?\n/).map(x=>x.trim()).filter(Boolean)}catch{}
 }
 const model=base.ramGB>=24?'qwen2.5-coder:14b':base.ramGB>=12?'qwen2.5-coder:7b':base.ramGB>=6?'qwen2.5-coder:3b':'qwen2.5-coder:1.5b';
 return {...base,gpu,recommendedModel:model};
}
async function startService(signal){
 if((await ai.health()).online)return true;
 const state=await installed();if(!state.installed)throw Error('Ollama is not installed');
 const exe=state.path||candidates()[0];
 const child=spawn(exe,['serve'],{detached:true,stdio:'ignore',windowsHide:true});
 child.on('error',()=>{});child.unref();
 for(let i=0;i<30;i++){if(signal?.aborted)throw Error('Cancelled');if((await ai.health()).online)return true;await wait(1000)}
 throw Error('Ollama service did not become ready. Check whether port 11434 is occupied.');
}
async function install({signal,progress=()=>{}}={}){
 if(process.platform!=='win32')throw Error('One-click installer currently supports Windows only.');
 let state=await installed();
 if(state.installed){progress({step:2,message:'Existing Ollama detected; skipping installation'});return state}
 progress({step:2,message:'Installing Ollama using Windows Package Manager'});
 try{
  await run('winget',['install','--id','Ollama.Ollama','--exact','--silent','--disable-interactivity','--accept-package-agreements','--accept-source-agreements'],{signal,timeout:600000,onOutput:x=>progress({step:2,message:x.trim().slice(-250)})});
 }catch(error){
  progress({step:2,message:'Package manager unavailable. Downloading official installer; Windows may request confirmation.'});
  const download=await installer.downloadOfficial({signal,onProgress:x=>progress({step:2,message:'Downloading installer',...x})});
  installer.launchInstaller(download);
  // The interactive installer cannot be assumed complete.
 }
 for(let i=0;i<120;i++){if(signal?.aborted)throw Error('Cancelled');state=await installed();if(state.installed)return state;await wait(2000)}
 throw Error('Installation not confirmed. Complete any Windows installer prompts and click Resume Setup.');
}
async function setup({model,signal,progress=()=>{}}={}){
 progress({step:1,message:'Detecting existing Ollama'});
 let state=await installed();
 if(!state.installed)state=await install({signal,progress});
 else progress({step:2,message:'Ollama already installed; existing installation preserved'});
 progress({step:3,message:'Starting or reconnecting to Ollama'});
 await startService(signal);
 progress({step:4,message:'Detecting CPU, RAM and GPU'});
 const hw=await hardware();
 const chosen=model||hw.recommendedModel;
 ai.modelName(chosen);
 const health=await ai.health();
 if(!health.models.some(x=>x.name===chosen)){
  progress({step:5,message:'Downloading '+chosen});
  await ai.pull(chosen,x=>progress({step:5,message:x.status,completed:x.completed,total:x.total}),signal);
 }else progress({step:5,message:'Model already downloaded: '+chosen});
 progress({step:6,message:'Testing local AI inference'});
 const response=await ai.chat({model:chosen,messages:[{role:'user',content:'Reply with exactly READY'}]},()=>{},signal);
 if(!response.trim())throw Error('AI model returned an empty response');
 progress({step:7,message:'Connected. AI Chat is ready',model:chosen});
 return {ready:true,model:chosen,hardware:hw,response:response.slice(0,200)};
}
module.exports={installed,hardware,startService,install,setup};
